/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  MapPin, 
  Camera, 
  User, 
  Home, 
  Search, 
  ArrowLeft, 
  Star, 
  Info, 
  Sparkles, 
  LogOut,
  ChevronRight,
  Settings,
  History,
  Heart,
  Navigation
} from 'lucide-react';
import { getPlaceDetails, recognizeLandmark } from './services/geminiService';
import { POPULAR_PLACES, Place } from './constants';

// --- Types ---
type Screen = 'splash' | 'login' | 'home' | 'details' | 'camera' | 'profile';

// --- Components ---

const SplashScreen = ({ onFinish }: { onFinish: () => void }) => {
  useEffect(() => {
    const timer = setTimeout(onFinish, 2500);
    return () => clearTimeout(timer);
  }, [onFinish]);

  return (
    <motion.div 
      initial={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-[#4A90E2] flex flex-col items-center justify-center z-50"
    >
      <motion.div
        initial={{ scale: 0.5, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.5, ease: "easeOut" }}
        className="flex flex-col items-center"
      >
        <div className="bg-white p-6 rounded-full shadow-2xl mb-6">
          <MapPin size={64} className="text-[#4A90E2]" />
        </div>
        <h1 className="text-white text-4xl font-bold tracking-tight">Smart Travel</h1>
        <p className="text-white/80 mt-2 text-lg">Discover places around you with AI</p>
      </motion.div>
    </motion.div>
  );
};

const LoginScreen = ({ onLogin }: { onLogin: () => void }) => {
  return (
    <div className="min-h-screen bg-[#F8FAFC] flex flex-col p-8 justify-center">
      <div className="mb-12 text-center">
        <h2 className="text-3xl font-bold text-[#1E293B]">Welcome Back</h2>
        <p className="text-slate-500 mt-2">Sign in to start your adventure</p>
      </div>
      
      <div className="space-y-4">
        <div className="space-y-2">
          <label className="text-sm font-semibold text-slate-700">Email Address</label>
          <input 
            type="email" 
            placeholder="traveler@example.com"
            className="w-full p-4 bg-white border border-slate-200 rounded-2xl focus:ring-2 focus:ring-[#4A90E2] outline-none transition-all"
          />
        </div>
        <div className="space-y-2">
          <label className="text-sm font-semibold text-slate-700">Password</label>
          <input 
            type="password" 
            placeholder="••••••••"
            className="w-full p-4 bg-white border border-slate-200 rounded-2xl focus:ring-2 focus:ring-[#4A90E2] outline-none transition-all"
          />
        </div>
        <button 
          onClick={onLogin}
          className="w-full bg-[#4A90E2] text-white py-4 rounded-2xl font-bold text-lg shadow-lg shadow-blue-200 hover:bg-blue-600 transition-colors mt-4"
        >
          Sign In
        </button>
      </div>
      
      <div className="mt-8 text-center">
        <p className="text-slate-500">Don't have an account? <span className="text-[#4A90E2] font-bold cursor-pointer">Sign Up</span></p>
      </div>
    </div>
  );
};

const HomeScreen = ({ 
  onSelectPlace, 
  onNavigate,
  favorites,
  toggleFavorite 
}: { 
  onSelectPlace: (p: Place) => void, 
  onNavigate: (s: Screen) => void,
  favorites: string[],
  toggleFavorite: (id: string) => void
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState('All');

  const categories = ['All', 'Landmark', 'Historical', 'Nature', 'Cultural', 'Modern'];

  const filteredPlaces = POPULAR_PLACES.filter(place => {
    const matchesSearch = place.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                         place.location.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = activeCategory === 'All' || place.category === activeCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="pb-24">
      <header className="p-6 bg-white sticky top-0 z-10 border-b border-slate-100">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h2 className="text-2xl font-bold text-[#1E293B]">Hello, Traveler!</h2>
            <p className="text-slate-500">Where to next?</p>
          </div>
          <div className="w-12 h-12 bg-slate-100 rounded-full flex items-center justify-center cursor-pointer" onClick={() => onNavigate('profile')}>
            <User className="text-slate-600" />
          </div>
        </div>
        
        <div className="relative mb-6">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
          <input 
            type="text" 
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search destinations..."
            className="w-full pl-12 pr-4 py-4 bg-slate-50 border-none rounded-2xl focus:ring-2 focus:ring-[#4A90E2] outline-none transition-all"
          />
        </div>

        <div className="flex gap-2 overflow-x-auto no-scrollbar pb-2">
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-5 py-2 rounded-full text-sm font-bold whitespace-nowrap transition-all ${
                activeCategory === cat 
                ? 'bg-[#4A90E2] text-white shadow-md shadow-blue-100' 
                : 'bg-slate-100 text-slate-500 hover:bg-slate-200'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </header>
      
      <main className="p-6 space-y-8">
        <section>
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-xl font-bold text-[#1E293B]">
              {searchQuery || activeCategory !== 'All' ? 'Search Results' : 'Popular Destinations'}
            </h3>
            <span className="text-sm text-slate-400 font-medium">{filteredPlaces.length} found</span>
          </div>
          
          <div className="grid grid-cols-1 gap-6">
            {filteredPlaces.length > 0 ? (
              filteredPlaces.map((place) => (
                <motion.div 
                  key={place.id}
                  layout
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  whileTap={{ scale: 0.98 }}
                  className="bg-white rounded-3xl overflow-hidden shadow-sm border border-slate-100 cursor-pointer relative group"
                >
                  <div onClick={() => onSelectPlace(place)}>
                    <img src={place.image} alt={place.name} className="w-full h-56 object-cover" referrerPolicy="no-referrer" />
                    <div className="p-5">
                      <div className="flex justify-between items-start">
                        <div>
                          <div className="flex items-center gap-2 mb-1">
                            <span className="px-2 py-0.5 bg-blue-50 text-[#4A90E2] text-[10px] font-bold rounded-md uppercase tracking-wider">
                              {place.category}
                            </span>
                            <span className="text-slate-400 text-[10px] font-bold">
                              {place.priceLevel}
                            </span>
                          </div>
                          <h4 className="font-bold text-xl text-[#1E293B]">{place.name}</h4>
                          <div className="flex items-center text-slate-500 text-sm mt-1">
                            <MapPin size={14} className="mr-1" />
                            {place.location}
                          </div>
                        </div>
                        <div className="flex items-center bg-yellow-50 px-2 py-1 rounded-lg">
                          <Star size={14} className="text-yellow-500 fill-yellow-500 mr-1" />
                          <span className="text-yellow-700 font-bold text-xs">{place.rating}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <button 
                    onClick={(e) => {
                      e.stopPropagation();
                      toggleFavorite(place.id);
                    }}
                    className="absolute top-4 right-4 w-10 h-10 bg-white/80 backdrop-blur-md rounded-full flex items-center justify-center shadow-md z-10"
                  >
                    <Heart 
                      size={20} 
                      className={favorites.includes(place.id) ? "text-red-500 fill-red-500" : "text-slate-400"} 
                    />
                  </button>
                </motion.div>
              ))
            ) : (
              <div className="text-center py-12">
                <div className="bg-slate-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Search size={32} className="text-slate-300" />
                </div>
                <p className="text-slate-500 font-medium">No destinations match your search.</p>
              </div>
            )}
          </div>
        </section>
        
        <section>
          <h3 className="text-xl font-bold text-[#1E293B] mb-4">AI Travel Assistant</h3>
          <div 
            onClick={() => onNavigate('camera')}
            className="bg-gradient-to-r from-[#4A90E2] to-[#50C878] p-6 rounded-3xl text-white shadow-xl cursor-pointer relative overflow-hidden group"
          >
            <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:scale-110 transition-transform">
              <Sparkles size={120} />
            </div>
            <div className="flex items-center justify-between relative z-10">
              <div>
                <h4 className="text-xl font-bold">Landmark Recognition</h4>
                <p className="text-white/80 text-sm mt-1">Point your camera to identify any landmark</p>
              </div>
              <Camera size={40} />
            </div>
          </div>
        </section>
      </main>
    </div>
  );
};

const PlaceDetailsScreen = ({ 
  place, 
  onBack,
  isFavorite,
  toggleFavorite
}: { 
  place: Place, 
  onBack: () => void,
  isFavorite: boolean,
  toggleFavorite: (id: string) => void
}) => {
  const [mode, setMode] = useState<'manual' | 'automatic'>('manual');
  const [aiDetails, setAiDetails] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  const fetchAiDetails = async () => {
    setLoading(true);
    const details = await getPlaceDetails(place.name);
    setAiDetails(details);
    setLoading(false);
  };

  useEffect(() => {
    if (mode === 'automatic' && !aiDetails) {
      fetchAiDetails();
    }
  }, [mode]);

  return (
    <div className="min-h-screen bg-white pb-12">
      <div className="relative h-96">
        <img src={place.image} alt={place.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
        <div className="absolute top-6 left-6 right-6 flex justify-between items-center">
          <button 
            onClick={onBack}
            className="w-10 h-10 bg-white/20 backdrop-blur-md rounded-full flex items-center justify-center text-white"
          >
            <ArrowLeft size={24} />
          </button>
          <button 
            onClick={() => toggleFavorite(place.id)}
            className="w-10 h-10 bg-white/20 backdrop-blur-md rounded-full flex items-center justify-center text-white"
          >
            <Heart size={24} className={isFavorite ? "fill-red-500 text-red-500" : ""} />
          </button>
        </div>
        <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-white to-transparent" />
      </div>
      
      <div className="px-6 -mt-12 relative z-10">
        <div className="flex justify-between items-start">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2 py-0.5 bg-blue-50 text-[#4A90E2] text-xs font-bold rounded-md uppercase tracking-wider">
                {place.category}
              </span>
              <span className="text-slate-400 text-xs font-bold">
                {place.priceLevel}
              </span>
            </div>
            <h2 className="text-3xl font-bold text-[#1E293B]">{place.name}</h2>
            <div className="flex items-center text-slate-500 mt-1">
              <MapPin size={18} className="mr-1" />
              {place.location}
            </div>
          </div>
          <div className="bg-[#4A90E2] text-white p-4 rounded-2xl shadow-lg shadow-blue-200">
            <Navigation size={28} />
          </div>
        </div>
        
        <div className="flex gap-2 mt-8 p-1 bg-slate-100 rounded-2xl">
          <button 
            onClick={() => setMode('manual')}
            className={`flex-1 py-3 rounded-xl font-bold transition-all ${mode === 'manual' ? 'bg-white text-[#4A90E2] shadow-sm' : 'text-slate-500'}`}
          >
            Manual Mode
          </button>
          <button 
            onClick={() => setMode('automatic')}
            className={`flex-1 py-3 rounded-xl font-bold flex items-center justify-center gap-2 transition-all ${mode === 'automatic' ? 'bg-white text-[#50C878] shadow-sm' : 'text-slate-500'}`}
          >
            <Sparkles size={18} />
            Automatic Mode
          </button>
        </div>
        
        <div className="mt-8">
          {mode === 'manual' ? (
            <div className="space-y-6">
              <div>
                <h4 className="text-lg font-bold text-[#1E293B] mb-2">Description</h4>
                <p className="text-slate-600 leading-relaxed">{place.description}</p>
              </div>
              <div className="grid grid-cols-3 gap-4">
                <div className="bg-slate-50 p-4 rounded-2xl text-center">
                  <Star className="text-yellow-500 mx-auto mb-1" size={20} />
                  <span className="block font-bold text-slate-700">{place.rating}</span>
                  <span className="text-xs text-slate-400">Rating</span>
                </div>
                <div className="bg-slate-50 p-4 rounded-2xl text-center">
                  <Info className="text-blue-500 mx-auto mb-1" size={20} />
                  <span className="block font-bold text-slate-700">Open</span>
                  <span className="text-xs text-slate-400">Status</span>
                </div>
                <div className="bg-slate-50 p-4 rounded-2xl text-center">
                  <MapPin className="text-green-500 mx-auto mb-1" size={20} />
                  <span className="block font-bold text-slate-700">2km</span>
                  <span className="text-xs text-slate-400">Distance</span>
                </div>
              </div>
              <div className="bg-blue-50 p-6 rounded-3xl border border-blue-100">
                <h4 className="text-blue-800 font-bold mb-2 flex items-center gap-2">
                  <Info size={18} />
                  Travel Tip
                </h4>
                <p className="text-blue-700 leading-relaxed">{place.tip}</p>
              </div>
            </div>
          ) : (
            <div className="space-y-6">
              {loading ? (
                <div className="flex flex-col items-center py-12">
                  <div className="w-12 h-12 border-4 border-[#50C878] border-t-transparent rounded-full animate-spin mb-4" />
                  <p className="text-slate-500 font-medium">AI is gathering details...</p>
                </div>
              ) : aiDetails ? (
                <motion.div 
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="space-y-6"
                >
                  <div className="bg-emerald-50 p-6 rounded-3xl border border-emerald-100">
                    <h4 className="text-emerald-800 font-bold mb-2 flex items-center gap-2">
                      <Sparkles size={18} />
                      AI Overview
                    </h4>
                    <p className="text-emerald-700 leading-relaxed">{aiDetails.overview}</p>
                  </div>
                  
                  <div>
                    <h4 className="text-lg font-bold text-[#1E293B] mb-3">Top Activities</h4>
                    <ul className="space-y-3">
                      {aiDetails.activities?.map((act: string, i: number) => (
                        <li key={i} className="flex items-center gap-3 bg-slate-50 p-4 rounded-2xl">
                          <div className="w-8 h-8 bg-white rounded-full flex items-center justify-center text-[#50C878] font-bold shadow-sm">
                            {i + 1}
                          </div>
                          <span className="text-slate-700 font-medium">{act}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-blue-50 p-4 rounded-2xl">
                      <h5 className="font-bold text-blue-800 text-sm mb-1">Best Time</h5>
                      <p className="text-blue-700 text-sm">{aiDetails.bestTime}</p>
                    </div>
                    <div className="bg-amber-50 p-4 rounded-2xl">
                      <h5 className="font-bold text-amber-800 text-sm mb-1">Local Tip</h5>
                      <p className="text-amber-700 text-sm">{aiDetails.localTip}</p>
                    </div>
                  </div>
                </motion.div>
              ) : (
                <p className="text-red-500">Failed to load AI details. Please try again.</p>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

const LandmarkRecognitionScreen = ({ onBack }: { onBack: () => void }) => {
  const [image, setImage] = useState<string | null>(null);
  const [result, setResult] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImage(reader.result as string);
        analyzeImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const analyzeImage = async (base64: string) => {
    setLoading(true);
    const analysis = await recognizeLandmark(base64);
    setResult(analysis);
    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-[#1E293B] flex flex-col">
      <header className="p-6 flex items-center gap-4 text-white">
        <button onClick={onBack} className="w-10 h-10 bg-white/10 rounded-full flex items-center justify-center">
          <ArrowLeft size={24} />
        </button>
        <h2 className="text-xl font-bold">Landmark Recognition</h2>
      </header>
      
      <main className="flex-1 flex flex-col p-6">
        <div className="flex-1 bg-slate-800 rounded-3xl overflow-hidden relative flex items-center justify-center border-2 border-dashed border-slate-700">
          {image ? (
            <img src={image} alt="Captured" className="w-full h-full object-cover" />
          ) : (
            <div className="text-center p-8">
              <Camera size={64} className="text-slate-600 mx-auto mb-4" />
              <p className="text-slate-400">Upload a photo of a landmark to identify it</p>
            </div>
          )}
          
          {loading && (
            <div className="absolute inset-0 bg-black/60 backdrop-blur-sm flex flex-col items-center justify-center text-white">
              <div className="w-12 h-12 border-4 border-[#4A90E2] border-t-transparent rounded-full animate-spin mb-4" />
              <p className="font-bold">Analyzing landmark...</p>
            </div>
          )}
        </div>
        
        <div className="mt-6 space-y-4">
          <input 
            type="file" 
            accept="image/*" 
            hidden 
            ref={fileInputRef}
            onChange={handleImageUpload}
          />
          <button 
            onClick={() => fileInputRef.current?.click()}
            className="w-full bg-[#4A90E2] text-white py-4 rounded-2xl font-bold flex items-center justify-center gap-2 shadow-lg"
          >
            <Camera size={20} />
            {image ? 'Change Photo' : 'Take / Upload Photo'}
          </button>
          
          {result && !loading && (
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-white p-6 rounded-3xl shadow-xl"
            >
              <h4 className="text-[#1E293B] font-bold mb-2 flex items-center gap-2">
                <Info size={18} className="text-[#4A90E2]" />
                Recognition Result
              </h4>
              <p className="text-slate-600 leading-relaxed">{result}</p>
            </motion.div>
          )}
        </div>
      </main>
    </div>
  );
};

const ProfileScreen = ({ onLogout, favorites }: { onLogout: () => void, favorites: string[] }) => {
  const favoritePlaces = POPULAR_PLACES.filter(p => favorites.includes(p.id));

  return (
    <div className="pb-24 bg-slate-50 min-h-screen">
      <header className="bg-white p-8 rounded-b-[3rem] shadow-sm border-b border-slate-100">
        <div className="flex flex-col items-center">
          <div className="w-24 h-24 bg-blue-100 rounded-full flex items-center justify-center mb-4 border-4 border-white shadow-lg">
            <User size={48} className="text-[#4A90E2]" />
          </div>
          <h2 className="text-2xl font-bold text-[#1E293B]">Bhavana</h2>
          <p className="text-slate-500">Explorer & Adventurer</p>
          
          <div className="flex gap-8 mt-6">
            <div className="text-center">
              <div className="text-xl font-bold text-[#1E293B]">{favorites.length}</div>
              <div className="text-xs text-slate-400 uppercase tracking-wider font-bold">Favorites</div>
            </div>
            <div className="text-center border-x border-slate-100 px-8">
              <div className="text-xl font-bold text-[#1E293B]">12</div>
              <div className="text-xs text-slate-400 uppercase tracking-wider font-bold">Trips</div>
            </div>
            <div className="text-center">
              <div className="text-xl font-bold text-[#1E293B]">4</div>
              <div className="text-xs text-slate-400 uppercase tracking-wider font-bold">Badges</div>
            </div>
          </div>
        </div>
      </header>
      
      <main className="p-6 space-y-8">
        <section>
          <h3 className="text-xl font-bold text-[#1E293B] mb-4">My Favorites</h3>
          {favoritePlaces.length > 0 ? (
            <div className="grid grid-cols-2 gap-4">
              {favoritePlaces.map(place => (
                <motion.div 
                  key={place.id}
                  whileHover={{ y: -5 }}
                  className="bg-white rounded-2xl overflow-hidden shadow-sm border border-slate-100"
                >
                  <img src={place.image} alt={place.name} className="w-full h-32 object-cover" referrerPolicy="no-referrer" />
                  <div className="p-3">
                    <h4 className="font-bold text-sm text-[#1E293B] truncate">{place.name}</h4>
                    <p className="text-slate-400 text-[10px] truncate">{place.location}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          ) : (
            <div className="bg-white p-8 rounded-3xl text-center border border-dashed border-slate-200">
              <Heart size={32} className="text-slate-200 mx-auto mb-2" />
              <p className="text-slate-400 text-sm">No favorites yet. Start exploring!</p>
            </div>
          )}
        </section>
        
        <section>
          <h3 className="text-xl font-bold text-[#1E293B] mb-4">Travel History</h3>
          <div className="space-y-4">
            {[1, 2].map(i => (
              <div key={i} className="bg-white p-4 rounded-2xl flex items-center gap-4 border border-slate-100">
                <div className="w-12 h-12 bg-slate-100 rounded-xl flex items-center justify-center">
                  <MapPin size={24} className="text-slate-400" />
                </div>
                <div className="flex-1">
                  <h4 className="font-bold text-slate-800">Trip to {i === 1 ? 'Paris' : 'Rome'}</h4>
                  <p className="text-xs text-slate-400">October 2023 • 5 days</p>
                </div>
                <ChevronRight size={20} className="text-slate-300" />
              </div>
            ))}
          </div>
        </section>
        
        <button 
          onClick={onLogout}
          className="w-full py-4 bg-red-50 text-red-500 font-bold rounded-2xl flex items-center justify-center gap-2 hover:bg-red-100 transition-colors mt-8"
        >
          <LogOut size={20} />
          Logout
        </button>
      </main>
    </div>
  );
};

// --- Main App ---

export default function App() {
  const [screen, setScreen] = useState<Screen>('splash');
  const [selectedPlace, setSelectedPlace] = useState<Place | null>(null);
  const [favorites, setFavorites] = useState<string[]>([]);

  const toggleFavorite = (id: string) => {
    setFavorites(prev => 
      prev.includes(id) ? prev.filter(fid => fid !== id) : [...prev, id]
    );
  };

  const handleSelectPlace = (place: Place) => {
    setSelectedPlace(place);
    setScreen('details');
  };

  return (
    <div className="max-w-md mx-auto bg-white min-h-screen shadow-2xl relative overflow-hidden font-sans">
      <AnimatePresence mode="wait">
        {screen === 'splash' && (
          <SplashScreen onFinish={() => setScreen('login')} />
        )}
        
        {screen === 'login' && (
          <motion.div key="login" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <LoginScreen onLogin={() => setScreen('home')} />
          </motion.div>
        )}
        
        {screen === 'home' && (
          <motion.div key="home" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <HomeScreen 
              onSelectPlace={handleSelectPlace} 
              onNavigate={setScreen} 
              favorites={favorites}
              toggleFavorite={toggleFavorite}
            />
          </motion.div>
        )}
        
        {screen === 'details' && selectedPlace && (
          <motion.div key="details" initial={{ x: '100%' }} animate={{ x: 0 }} exit={{ x: '100%' }} transition={{ type: 'spring', damping: 25, stiffness: 200 }}>
            <PlaceDetailsScreen 
              place={selectedPlace} 
              onBack={() => setScreen('home')} 
              isFavorite={favorites.includes(selectedPlace.id)}
              toggleFavorite={toggleFavorite}
            />
          </motion.div>
        )}
        
        {screen === 'camera' && (
          <motion.div key="camera" initial={{ y: '100%' }} animate={{ y: 0 }} exit={{ y: '100%' }} transition={{ type: 'spring', damping: 25, stiffness: 200 }}>
            <LandmarkRecognitionScreen onBack={() => setScreen('home')} />
          </motion.div>
        )}
        
        {screen === 'profile' && (
          <motion.div key="profile" initial={{ x: '-100%' }} animate={{ x: 0 }} exit={{ x: '-100%' }} transition={{ type: 'spring', damping: 25, stiffness: 200 }}>
            <ProfileScreen onLogout={() => setScreen('login')} favorites={favorites} />
          </motion.div>
        )}
      </AnimatePresence>

      {/* Navigation Bar */}
      {(screen === 'home' || screen === 'profile') && (
        <nav className="fixed bottom-0 left-0 right-0 max-w-md mx-auto bg-white/80 backdrop-blur-lg border-t border-slate-100 p-4 flex justify-around items-center z-20">
          <button 
            onClick={() => setScreen('home')}
            className={`p-2 rounded-xl transition-colors ${screen === 'home' ? 'text-[#4A90E2] bg-blue-50' : 'text-slate-400'}`}
          >
            <Home size={24} />
          </button>
          <button 
            onClick={() => setScreen('camera')}
            className="p-4 bg-[#4A90E2] text-white rounded-2xl shadow-lg -mt-12 border-4 border-white active:scale-95 transition-transform"
          >
            <Camera size={28} />
          </button>
          <button 
            onClick={() => setScreen('profile')}
            className={`p-2 rounded-xl transition-colors ${screen === 'profile' ? 'text-[#4A90E2] bg-blue-50' : 'text-slate-400'}`}
          >
            <User size={24} />
          </button>
        </nav>
      )}
    </div>
  );
}
