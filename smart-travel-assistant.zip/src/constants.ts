export interface Place {
  id: string;
  name: string;
  location: string;
  description: string;
  image: string;
  rating: number;
  category: string;
  priceLevel: string;
  tip: string;
}

export const POPULAR_PLACES: Place[] = [
  {
    id: "1",
    name: "Eiffel Tower",
    location: "Paris, France",
    description: "The iconic iron lattice tower on the Champ de Mars.",
    image: "https://picsum.photos/seed/paris/800/600",
    rating: 4.8,
    category: "Landmark",
    priceLevel: "$$",
    tip: "Book tickets online in advance to skip the long lines.",
  },
  {
    id: "2",
    name: "Colosseum",
    location: "Rome, Italy",
    description: "An oval amphitheatre in the centre of the city of Rome.",
    image: "https://picsum.photos/seed/rome/800/600",
    rating: 4.7,
    category: "Historical",
    priceLevel: "$$",
    tip: "Visit early in the morning or late afternoon for better light and fewer crowds.",
  },
  {
    id: "3",
    name: "Machu Picchu",
    location: "Cusco Region, Peru",
    description: "A 15th-century Inca citadel located in the Eastern Cordillera.",
    image: "https://picsum.photos/seed/peru/800/600",
    rating: 4.9,
    category: "Historical",
    priceLevel: "$$$",
    tip: "Acclimatize to the altitude in Cusco for a few days before visiting.",
  },
  {
    id: "4",
    name: "Kyoto Temples",
    location: "Kyoto, Japan",
    description: "Beautiful historic temples and traditional gardens.",
    image: "https://picsum.photos/seed/kyoto/800/600",
    rating: 4.8,
    category: "Cultural",
    priceLevel: "$",
    tip: "Wear comfortable shoes as you'll be doing a lot of walking.",
  },
  {
    id: "5",
    name: "Taj Mahal",
    location: "Agra, India",
    description: "An ivory-white marble mausoleum on the south bank of the Yamuna river.",
    image: "https://picsum.photos/seed/tajmahal/800/600",
    rating: 4.9,
    category: "Historical",
    priceLevel: "$$",
    tip: "The Taj Mahal is closed on Fridays, so plan accordingly.",
  },
  {
    id: "6",
    name: "Santorini",
    location: "Cyclades, Greece",
    description: "Famous for its stunning sunsets, white-washed buildings, and blue domes.",
    image: "https://picsum.photos/seed/santorini/800/600",
    rating: 4.8,
    category: "Nature",
    priceLevel: "$$$",
    tip: "Rent a scooter or ATV to explore the island's hidden beaches.",
  },
  {
    id: "7",
    name: "Great Wall of China",
    location: "Huairou, China",
    description: "A series of fortifications that were built across the historical northern borders of ancient Chinese states.",
    image: "https://picsum.photos/seed/greatwall/800/600",
    rating: 4.7,
    category: "Historical",
    priceLevel: "$$",
    tip: "Visit the Mutianyu section for a less crowded experience and a fun toboggan ride down.",
  },
  {
    id: "8",
    name: "Grand Canyon",
    location: "Arizona, USA",
    description: "A steep-sided canyon carved by the Colorado River in Arizona.",
    image: "https://picsum.photos/seed/grandcanyon/800/600",
    rating: 4.9,
    category: "Nature",
    priceLevel: "$",
    tip: "Stay for sunset at Mather Point for breathtaking views.",
  },
  {
    id: "9",
    name: "Petra",
    location: "Ma'an, Jordan",
    description: "A famous archaeological site in Jordan's southwestern desert.",
    image: "https://picsum.photos/seed/petra/800/600",
    rating: 4.8,
    category: "Historical",
    priceLevel: "$$$",
    tip: "Don't miss the 'Petra by Night' experience for a magical candlelit atmosphere.",
  },
  {
    id: "10",
    name: "Sydney Opera House",
    location: "Sydney, Australia",
    description: "A multi-venue performing arts centre in Sydney.",
    image: "https://picsum.photos/seed/sydney/800/600",
    rating: 4.7,
    category: "Modern",
    priceLevel: "$$",
    tip: "Take a guided tour to learn about the fascinating history and architecture.",
  },
];
