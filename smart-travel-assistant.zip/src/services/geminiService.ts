import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export const getPlaceDetails = async (placeName: string) => {
  const model = "gemini-3-flash-preview";
  const prompt = `Provide detailed travel information for "${placeName}". Include:
  1. A brief overview.
  2. Top 3 things to do.
  3. Best time to visit.
  4. A local tip.
  Format the response as JSON with keys: overview, activities (array of strings), bestTime, localTip.`;

  try {
    const response = await ai.models.generateContent({
      model,
      contents: [{ parts: [{ text: prompt }] }],
      config: {
        responseMimeType: "application/json",
      },
    });
    return JSON.parse(response.text || "{}");
  } catch (error) {
    console.error("Error fetching place details:", error);
    return null;
  }
};

export const recognizeLandmark = async (base64Image: string) => {
  const model = "gemini-3-flash-preview";
  const prompt = "Identify this landmark and provide a short description and its location.";

  try {
    const response = await ai.models.generateContent({
      model,
      contents: [
        {
          parts: [
            { text: prompt },
            {
              inlineData: {
                mimeType: "image/jpeg",
                data: base64Image.split(",")[1],
              },
            },
          ],
        },
      ],
    });
    return response.text;
  } catch (error) {
    console.error("Error recognizing landmark:", error);
    return "Could not identify the landmark. Please try again.";
  }
};
